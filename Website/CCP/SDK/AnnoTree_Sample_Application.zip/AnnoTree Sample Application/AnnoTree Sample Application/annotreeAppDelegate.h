//
//  annotreeAppDelegate.h
//  AnnoTree Sample Application
//
//  Created by Brian Clark on 7/31/13.
//  Copyright (c) 2013 AnnoTree. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface annotreeAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

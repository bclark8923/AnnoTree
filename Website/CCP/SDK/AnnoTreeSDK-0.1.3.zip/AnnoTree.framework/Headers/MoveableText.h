//
//  MoveableText.h
//  AnnoTree Viewer
//
//  Created by Michael Max on 8/8/13.
//  Copyright (c) 2013 AnnoTree. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoveableText : UITextField

@end

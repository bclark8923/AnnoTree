//
//  main.m
//  AnnoTree Sample Application
//
//  Created by Brian Clark on 7/31/13.
//  Copyright (c) 2013 AnnoTree. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "annotreeAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([annotreeAppDelegate class]));
    }
}

<!doctype html>
<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if IE 9]>    <html class="no-js ie9" lang="en"> <![endif]-->
<!-- Consider adding an manifest.appcache: h5bp.com/d/Offline -->
<!--[if gt IE 9]><!--> <html class="no-js" lang="en" itemscope> <!--<![endif]-->
<head>
  <meta charset="utf-8">

  <!-- Use the .htaccess and remove these lines to avoid edge case issues.
       More info: h5bp.com/b/378 -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <title>AnnoTree - A New Way to Organize and Collaborate on Mobile Design and Testing</title>
  <meta name="description" content="" />
  <meta name="keywords" content="" />
  <meta name="author" content="humans.txt">

  <link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
  <link rel="icon" type="image/png" href="favicon.png" />

  <!-- Facebook Metadata /-->
  <meta property="fb:page_id" content="" />
  <meta property="og:image" content="" />
  <meta property="og:description" content=""/>
  <meta property="og:title" content=""/>

  <!-- Google+ Metadata /-->
  <meta itemprop="name" content="">
  <meta itemprop="description" content="">
  <meta itemprop="image" content="">

  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1 user-scalable=no">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">

  <!-- We highly recommend you use SASS and write your custom styles in sass/_custom.scss.
       However, there is a blank style.css in the css directory should you prefer -->
  <link href="http://fonts.googleapis.com/css?family=Lato:300" rel="stylesheet" type="text/css">

  <link rel="stylesheet" href="css/gumby.css">
  <link rel="stylesheet" href="css/style.css">

  <script src="js/libs/modernizr-2.6.2.min.js"></script>
</head>

<body>
  <div class="navbar fixed responsiveHide" gumby-fixed="top" id="annoTreeNavbar">
		<div class="row">
			<div class="three columns valign">
        <div class="navLinks"><a href="#"><img src="img/LogoNameWeb.png"/></a></div>
      </div>
      <div class="one columns push_four valign">
        <div class="navLinks"><a href="#" class="skip" gumby-goto="top">Home</a></div>
      </div>
      <div class="one columns valign">
        <div class="navLinks"><a href="#" class="skip" gumby-goto="#product">Product</a></div>
      </div>
      <div class="one columns valign">
        <div class="navLinks"><a href="#" class="skip" gumby-goto="#contact">Contact</a></div>
      </div>
      <div class="one columns valign">
        <div class="navLinks"><a href="http://annotree.com/blog">Blog</a></div>
      </div>
      <div class="one columns valign">
        <div>
          <div class="small oval btn success"><a href="/CCPAngular">Login</a></div>
        </div>
      </div>
		</div>
	</div>
  <div class="navbar fixed responsiveShow" gumby-fixed="top">
		<div style="width: 130px; float:left;" class="navLinks">
      <div style="padding:5px; padding-top: 10px;">
        <a href="#"><img src="img/LogoNameWeb.png"/></a>
      </div>
    </div>
    <div style="width: 80px; float:right; padding-top:5px;" class="navLinks">
      <div style="padding:5px;">
        <div class="small oval btn success"><a href="/CCPAngular">Login</a></div>
      </div>
    </div>
    <div style="width: 80px; float:right; padding-top:5px;" class="navLinks">
      <div style="padding:5px;">
        <a style="color:#444;" href="http://blog.annotree.com">Blog</a>
      </div>
    </div>
	</div>
  <div id="content">
    <div id="mainTitle" class="valign">
      <div id="titleContent">
        <!-- <div>
          <span>A New Way to Organize and Collaborate on</span>
        </div>
        <div>
          <span>Mobile Design and Testing</span>
        </div>-->
        <div id="titleContentLine">
          A New Way to Organize and Collaborate on<br/>
          Mobile Design and Testing
        </div>
        <div>
          <div class="medium oval btn success icon-right entypo icon-right-circled"><a href="/CCPAngular/#authenticate/signUp">Sign Up Free</a></div>
        </div>
      </div>
    </div>
    <div id="why">
      <div class="row">
        <div class="twelve columns">
          <p class="sectionHeaderText">Organizing the Unorganized</p>
        </div>
      </div>
      <div class="row">
        <div class="six columns">          
          <p class="whyParagraphs">Our Team comes from over 30 combined years of programming experience across multiple platforms.  
          Upon moving into developing in the mobile space we found many pains in collecting feedback
          directly from users with full context, both visually and programatically.</p>
        </div>
        <div class="six columns">       
          <p class="whyParagraphs">To solve this solution we went out to build a platform that would give us, and many others,
          a much faster, simpler, more organized way of collecting and reviewing design and bug flaws in a single, collaborative
          platform for any device and any situation.</p>
        </div>
      </div>
    </div>
    <div id="product">
      <div class="row">
        <div class="twelve columns">
          <p class="sectionHeaderText">The Product</p>
        </div>
      </div>
      <div class="row" style="margin-top: 50px; text-align:center;">
        <div class="four columns productColumn">
          <ul class="one_up tiles" style="text-align:center;">
            <li style="width:100%;">
              <div>
                <img  class="productScreenShot" style="margin-top:50px;" src="img/iPhoneScreenshot.png"/>
              </div>
            </li>
            <li>The AnnoTree SDK allows anyone to draw or write directly on any mobile application to denote a design flaw or bug.</li>
          </ul>
        </div>
        <div class="four columns productColumn">
          <ul class="one_up tiles" style="text-align:center;">
            <li style="width:100%;"><img class="productScreenShot" src="img/Cloud.png"/></li>
            <li>They can then send these "leafs" off to our central collaboration platform</li>
          </ul>
        </div>
        <div class="four columns productColumn">
          <ul class="one_up tiles" style="text-align:center;">
            <li style="width:100%;"><img class="productScreenShot" src="img/devicesScreenshot.png"/></li>
            <li>Here the application creators can organize and collaborate on these "leafs" across multiple devices.</li>
          </ul>
        </div>
      </div>
      <!--
      <div class="row">
        <div class="six columns valign" id="iPhoneDescription">
          <div>
            <p>The AnnoTree SDK allows you to draw or write directly on any mobile application to denote a design flaw or bug.</p>
          </div>
        </div>
        <div class="six columns" id="iPhoneImage">
          <div>
            <img class="iPhoneScrenshot" src="img/iPhoneScreenshot.png"/>
          </div>
        </div>
      </div>
      <div class="row responsiveHide">
        <div class="six columns" style="text-align: center; height: 300px;">
          <div>
            <img class="iPhoneScrenshot" src="img/devicesScreenshot.png"/>
          </div>
        </div>
        <div class="six columns valign" style="height:350px;">
          <div>
            <p>You can then send, organize and collaborate on these "leafs" in our central collaboration platform across multiple devices.</p>
          </div>
        </div>
      </div>
      <div class="row responsiveShow">
        <div class="six columns valign" style="height:200px;">
          <div>
            <p>You can then send, organize and collaborate on these "leafs" in our central collaboration platform across multiple devices.</p>
          </div>
        </div>
        <div class="six columns" style="text-align: center; height: 200px;">
          <div>
            <img class="iPhoneScrenshot" src="img/devicesScreenshot.png"/>
          </div>
        </div>
      </div>
      -->
    </div>
    <div id="contact">
      <div class="row">
        <div class="twelve columns">
          <p class="sectionHeaderText">Contact</p>
          
          <p class="contactInfo">Contact@AnnoTree.com  |  <a style="color:#58c026;"href="http://twitter/com/annotree">@AnnoTree</a></p>
        </div>
      </div>
    </div>
    <div id="footer">
      <div class="row" style="height:100%;">
        <div class="valign" style="height:100%;">
          <div>
            <a href="http://Silith.IO"><img class="grayScale" src="img/SilithIOLogoOnly.png" style="height:20px;"/></a>
            <p class="footerText">&copy; Copyright 2013 Silith.IO</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Grab Google CDN's jQuery, fall back to local if offline -->
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="js/libs/jquery-1.9.1.min.js"><\/script>')</script>

  <!--
  Include gumby.js followed by UI modules.
  Or concatenate and minify into a single file
  <script src="js/libs/gumby.js"></script>
  <script src="js/libs/ui/gumby.retina.js"></script>
  <script src="js/libs/ui/gumby.fixed.js"></script>
  <script src="js/libs/ui/gumby.skiplink.js"></script>
  <script src="js/libs/ui/gumby.toggleswitch.js"></script>
  <script src="js/libs/ui/gumby.checkbox.js"></script>
  <script src="js/libs/ui/gumby.radiobtn.js"></script>
  <script src="js/libs/ui/gumby.tabs.js"></script>
  <script src="js/libs/ui/gumby.navbar.js"></script>
  <script src="js/libs/ui/gumby.fittext.js"></script>
  <script src="js/libs/ui/jquery.validation.js"></script>
  <script src="js/libs/gumby.init.js"></script>-->
  
  <script src="js/libs/gumby.min.js"></script>
  <script src="js/plugins.js"></script>
  <script src="js/main.js"></script>

  <!-- Change UA-XXXXX-X to be your site's ID -->
  <!--<script>
    window._gaq = [['_setAccount','UAXXXXXXXX1'],['_trackPageview'],['_trackPageLoadTime']];
    Modernizr.load({
      load: ('https:' == location.protocol ? '//ssl' : '//www') + '.google-analytics.com/ga.js'
    });
  </script>-->

  <!-- Prompt IE 6 users to install Chrome Frame. Remove this if you want to support IE 6.
       chromium.org/developers/how-tos/chrome-frame-getting-started -->
  <!--[if lt IE 7 ]>
    <script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.3/CFInstall.min.js"></script>
    <script>window.attachEvent('onload',function(){CFInstall.check({mode:'overlay'})})</script>
  <![endif]-->

  </body>
</html>

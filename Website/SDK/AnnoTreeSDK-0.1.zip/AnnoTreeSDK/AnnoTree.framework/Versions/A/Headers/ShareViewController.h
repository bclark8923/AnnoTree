//
//  ShareViewController.h
//  AnnoTree Viewer
//
//  Created by Brian Clark on 4/14/13.
//  Copyright (c) 2013 AnnoTree. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareViewController : UIViewController

@property (nonatomic, retain) UIButton* closeShareView;

@end

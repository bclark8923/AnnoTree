//
//  Rectangle.h
//  AnnoTree Viewer
//
//  Created by Brian Clark on 4/13/13.
//  Copyright (c) 2013 AnnoTree. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ToolbarBg : UIView

@end

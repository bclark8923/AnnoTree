
  <div id="footer">
    <div class="row" style="height:100%;">
      <div class="valign" style="height:100%;">
        <div>
          <a href="http://Silith.IO"><img class="grayScale" src="img/SilithIOLogoOnly.png" style="height:20px;"/></a>
          <p class="footerText">&copy; Copyright 2013 Silith.IO</p>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Grab Google CDN's jQuery, fall back to local if offline -->
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="js/libs/jquery-1.9.1.min.js"><\/script>')</script>

  </body>
</html>
